﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class ScoreManager : MonoBehaviour {

	public static int scoreMod;	//Score modifier
	public static int score;	//Score count
	
	public static float lifeBar = 1f;	//Lifebar, 0 is death, 1 is full

	void Start () {	//Resets score and initialised the score and modifier UI components
		ResetScore ();

		UIManager.OnScoreChange (score);
		UIManager.OnModifierChange (scoreMod);
	}

	void Update () {
		LifeBarTickdown ();
		LifeBarLimiter ();
		
		if (lifeBar <= 0) {	//Game over if that lifebar is empty
			GameOver ();
		}

	}

	void LifeBarLimiter () {	//Stops the life bar from going over 1
		if (lifeBar > 1) {
			lifeBar = 1;
		}
	}

	void LifeBarTickdown () {	//Ticks down the life bar and updates the UI element
		lifeBar -= 0.05f * Time.deltaTime * (SpeedManager.speedMod / 3);
		UIManager.OnLifeBarChange (lifeBar);
	}

	public static void ResetScore () {	//Resets the score and the object spawning chance whenever the game restarts
		score = 0;
		scoreMod = 1;
		lifeBar = 1f;
		ObjectSpawner.chanceToSpawn = 50f;
	}

	public static void AddScore (int i) {	//Adds score, updates the UI element and increases the life bar 
		score += i * scoreMod;
		UIManager.OnScoreChange (score);
		lifeBar += 0.2f;
	}

	public static void IncreaseModifier () {	//Adds to the modifier and updates the UI element
		scoreMod += 1;
		UIManager.OnModifierChange (scoreMod);
	}

	public static void ResetModifier () {	//Sets the modifier back to 0 and updates the UI element
		scoreMod = 1;
		UIManager.OnModifierChange (scoreMod);
	}

	public static void RemoveLife () {	//Decreases the life bar 
		lifeBar -= 0.15f;
	}
	
	static void GameOver () {	//Reloads the scene when the player is out of life
		SceneManager.LoadScene (SceneManager.GetActiveScene ().buildIndex);
	}
}
