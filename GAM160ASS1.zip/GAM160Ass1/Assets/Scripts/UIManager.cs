﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class UIManager : MonoBehaviour {

	public static Text modifierText;
	public static Text scoreText;
	public static Image lifeBar;
	public static Text lifeText;

	void Start(){	//Sets UI components
		modifierText = GameObject.FindGameObjectWithTag ("Multiplier").GetComponent<Text>();
		scoreText = GameObject.FindGameObjectWithTag ("Score").GetComponent<Text> ();
		lifeBar = GameObject.FindGameObjectWithTag ("Life Bar").GetComponent<Image> ();
	}

	public static void OnScoreChange(int i){	//When told the score has changed, change the score text
		scoreText.text = i.ToString ();
	}

	public static void OnModifierChange(int i){	//When told the modifier has changed, change the modifier text
		modifierText.text = i.ToString ();
	}
	
	public static void OnLifeBarChange (float f) {	//When told the life bar has changed, change the lifebar text
		lifeBar.fillAmount = f;
	}
}