﻿using UnityEngine;
using System.Collections;
using System.IO.Ports;

public class ArduinoInputManager : MonoBehaviour {

	SerialPort stream = new SerialPort ("COM3", 9600);  //SerialPort used for Arduino input

	bool _inputRight;
	bool _inputLeft;

	string input;

	public GameObject rightCrusher;
	public GameObject leftCrusher;

	void Start () {
		//Sets the timeout to 25ms and opens the connection
		stream.Open ();
		stream.ReadTimeout = 25;
	}

	void Update () {
		//Sets input to the serial from the Arduino
		input = stream.ReadLine ();

		//Changes the bool value of the right/left crusher based on inputs
		if (input == "Input Right") {
			rightCrusher.GetComponent<Crusher> ().ChangeInputStates (0);
			leftCrusher.GetComponent<Crusher> ().ChangeInputStates (0);
			Debug.Log ("Right");
		} else if (input == "Input Left") {
			rightCrusher.GetComponent<Crusher> ().ChangeInputStates (1);
			leftCrusher.GetComponent<Crusher> ().ChangeInputStates (1);
			Debug.Log ("Left");
		} else if (input == "Input Both") {
			rightCrusher.GetComponent<Crusher> ().ChangeInputStates (2);
			leftCrusher.GetComponent<Crusher> ().ChangeInputStates (2);
			Debug.Log ("Both");
		} else {
			rightCrusher.GetComponent<Crusher> ().ChangeInputStates (3);
			leftCrusher.GetComponent<Crusher> ().ChangeInputStates (3);
			Debug.Log ("Neither");
		}
	}
}
