﻿using UnityEngine;
using System.Collections;

public class ObjectVelocity : MonoBehaviour {

	Rigidbody rb;

	void Start () {
		rb = GetComponent<Rigidbody> ();
	}

	void Update () {	//Sets the object velocity to the current speed 
		rb.velocity = new Vector3 (0, 0, 100f * SpeedManager.speedMod) * Time.deltaTime;
	}
}
