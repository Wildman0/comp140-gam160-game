﻿using UnityEngine;
using System.Collections;
using System.IO.Ports;

public class Crusher : MonoBehaviour {

	SerialPort stream = new SerialPort ("COM3", 9600);  //SerialPort used for Arduino input

	bool _inputRight;
	bool _inputLeft;

	string input;

	void Start () {
		//Sets the timeout to 20ms and opens the connection
		stream.Open ();
		stream.ReadTimeout = 20;
	}

	void Update () {
		
		input = stream.ReadLine ();

		if (input == "Input Right") {
			_inputLeft = false;
			_inputRight = true;
			Debug.Log ("Right");
		} else if (input == "Input Left") {
			_inputLeft = true;
			_inputRight = false;
			Debug.Log ("Left");
		} else if (input == "Input Both") {
			_inputLeft = true;
			_inputRight = true;
			Debug.Log ("Both");
		} else {
			_inputLeft = false;
			_inputRight = false;
			Debug.Log ("Neither");
		}
	}

	void OnTriggerStay (Collider coll) {	//While an object is in the crusher
		if (Input.GetKey (KeyCode.Z) && gameObject.tag == "Left Crusher") {	//If it's the left crusher
			if (coll.gameObject.tag == "Hittable Object") { //If the object is hittable
				//Hit the object and destroy the gameObject

				OnHitHittableObj ();
				Destroy (coll.gameObject);
			} else if (coll.gameObject.tag == "Unhittable Object") {    //Else if the object isn't hittable
				//Hit the unhittable object

				OnHitUnhittableObj ();
			}
		} else if (Input.GetKey (KeyCode.X) && gameObject.tag == "Right Crusher") {	//Ditto for the right crusher
			if (coll.gameObject.tag == "Hittable Object") {
				OnHitHittableObj ();
				Destroy (coll.gameObject);
			} else if (coll.gameObject.tag == "Unhittable Object") {
				OnHitUnhittableObj();
				Destroy (coll.gameObject);
			}
		}

		//Identical functionality for Arduino input rather than keyboard
		
		if (_inputRight && gameObject.tag == "Right Crusher") { //Ditto for the right crusher
			if (coll.gameObject.tag == "Hittable Object") {
				OnHitHittableObj ();
				Destroy (coll.gameObject);
			} else if (coll.gameObject.tag == "Unhittable Object") {
				OnHitUnhittableObj ();
				Destroy (coll.gameObject);
			}
		}

		if (_inputLeft && gameObject.tag == "Left Crusher") { //If it's the left crusher
			if (coll.gameObject.tag == "Hittable Object") { //If the object is hittable
				//Hit the object and destroy the gameObject

				OnHitHittableObj ();
				Destroy (coll.gameObject);
			} else if (coll.gameObject.tag == "Unhittable Object") {    //Else if the object isn't hittable, Hit the unhittable object
				OnHitUnhittableObj ();
				Destroy (coll.gameObject);
			}
		}
	}

	void OnHitHittableObj () {	//Add score and increase the modifier when a hittable object is hit
		ScoreManager.AddScore (500);
		ScoreManager.IncreaseModifier ();
	}

	void OnHitUnhittableObj () {	//Reset the modifier and remove life when an unhittable object is hit
		ScoreManager.ResetModifier ();
		ScoreManager.RemoveLife ();
	}
}