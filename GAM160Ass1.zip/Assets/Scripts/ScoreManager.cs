﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class ScoreManager : MonoBehaviour {

	public static int scoreMod;
	public static int score;

	public static int life = 5;
	public static float lifeBar = 1f;

	void Start () {
		ResetScore ();

		UIManager.OnScoreChange (score);
		UIManager.OnModifierChange (scoreMod);
	}

	void Update () {
		LifeBarTickdown ();
		LifeBarLimiter ();
		
		if (lifeBar <= 0) {
			GameOver ();
		}

	}

	void LifeBarLimiter () {
		if (lifeBar > 1) {
			lifeBar = 1;
		}
	}

	void LifeBarTickdown () {
		lifeBar -= 0.05f * Time.deltaTime * (SpeedManager.speedMod / 3);
		UIManager.OnLifeBarChange (lifeBar);
	}

	public static void ResetScore () {
		score = 0;
		scoreMod = 1;
		life = 5;
		lifeBar = 1f;
	}

	public static void AddScore (int i) {
		score += i * scoreMod;
		UIManager.OnScoreChange (score);
		lifeBar += 0.2f;
	}

	public static void IncreaseModifier () {
		scoreMod += 1;
		UIManager.OnModifierChange (scoreMod);
	}

	public static void ResetModifier () {
		scoreMod = 1;
		UIManager.OnModifierChange (scoreMod);
	}

	public static void RemoveLife () {
		lifeBar -= 0.15f;
	}
	
	static void GameOver () {
		SceneManager.LoadScene (SceneManager.GetActiveScene ().buildIndex);
	}
}
