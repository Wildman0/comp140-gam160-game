﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class ScoreManager : MonoBehaviour {

	public static int scoreMod;
	public static int score;

	public static int life = 5; 

	void Start () {
		ResetScore ();
		life = 5;
	}

	public static void ResetScore () {
		score = 0;
		scoreMod = 1;
	}

	public static void AddScore (int i) {
		score += i * scoreMod;
		UIManager.OnScoreChange (score);
	}

	public static void IncreaseModifier () {
		scoreMod += 1;
		UIManager.OnModifierChange (scoreMod);
	}

	public static void ResetModifier () {
		scoreMod = 1;
		UIManager.OnModifierChange (scoreMod);
	}

	public static void RemoveLife () {
		life -= 1;
		UIManager.OnLifeCountChange (life);
		if (life == 0) {
			GameOver ();
		}
	}

	static void GameOver () {
		SceneManager.LoadScene (SceneManager.GetActiveScene ().buildIndex);
	}
}
