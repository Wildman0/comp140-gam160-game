﻿using UnityEngine;
using System.Collections;

public class ObjectVelocity : MonoBehaviour {

	Rigidbody rb;

	void Start () {
		rb = GetComponent<Rigidbody> ();
	}

	void Update () {
		rb.velocity = new Vector3 (0, 0, 100f * SpeedManager.speedMod) * Time.deltaTime;
	}
}
