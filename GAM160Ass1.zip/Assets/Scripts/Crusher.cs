﻿using UnityEngine;
using System.Collections;

public class Crusher : MonoBehaviour {

	void OnTriggerStay (Collider coll) {
		if (Input.GetKeyDown (KeyCode.Z) && this.gameObject.tag == "Left Crusher") {
			if (coll.gameObject.tag == "Hittable Object") {
				ScoreManager.AddScore (500);
				ScoreManager.IncreaseModifier ();
				Destroy (coll.gameObject);
			} else if (coll.gameObject.tag == "Unhittable Object") {
				ScoreManager.ResetModifier ();
			}
		} else if (Input.GetKeyDown (KeyCode.X) && this.gameObject.tag == "Right Crusher") {
			if (coll.gameObject.tag == "Hittable Object") {
				ScoreManager.AddScore (500);
				ScoreManager.IncreaseModifier ();
				Destroy (coll.gameObject);
			}
		} else if (coll.gameObject.tag == "Unhittable Object") {
			ScoreManager.ResetModifier ();
		}
	}
}