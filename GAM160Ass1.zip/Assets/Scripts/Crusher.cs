﻿using UnityEngine;
using System.Collections;

public class Crusher : MonoBehaviour {

	void OnTriggerStay (Collider coll) {	//While an object is in the crusher
		if (Input.GetKey (KeyCode.Z) && gameObject.tag == "Left Crusher") {	//If it's the left crusher
			if (coll.gameObject.tag == "Hittable Object") { //If the object is hittable
				//Hit the object and destroy the gameObject

				OnHitHittableObj ();
				Destroy (coll.gameObject);
			} else if (coll.gameObject.tag == "Unhittable Object") {    //Else if the object isn't hittable
				//Hit the unhittable object

				OnHitUnhittableObj ();
			}
		} else if (Input.GetKey (KeyCode.X) && gameObject.tag == "Right Crusher") {	//Ditto for the right crusher
			if (coll.gameObject.tag == "Hittable Object") {
				OnHitHittableObj ();
				Destroy (coll.gameObject);
			} else if (coll.gameObject.tag == "Unhittable Object") {
				OnHitUnhittableObj();
			}
		}
	}

	void OnHitHittableObj () {	//Add score and increase the modifier when a hittable object is hit
		ScoreManager.AddScore (500);
		ScoreManager.IncreaseModifier ();
	}

	void OnHitUnhittableObj () {	//Reset the modifier and remove life when an unhittable object is hit
		ScoreManager.ResetModifier ();
		ScoreManager.RemoveLife ();
	}

	void Update () {
		/*if (Input.GetKeyDown (KeyCode.Z)){
			foreach (GameObject go in ObjectManager.spawnedObjects) {
				if (go.GetComponent<ObjectUtilities>().inCrusher == ObjectUtilities.crusherState.left) {
					if (go.tag == "Hittable Object") {
						ScoreManager.AddScore (500);
						ScoreManager.IncreaseModifier ();
					} else if (go.tag == "Unhittable Object") {
						ScoreManager.ResetModifier();
					}
				}
			}
		} else if (Input.GetKeyDown (KeyCode.X)) {
			foreach (GameObject go in ObjectManager.spawnedObjects) {
				if (go.GetComponent<ObjectUtilities> ().inCrusher == ObjectUtilities.crusherState.right) {
					if (go.tag == "Hittable Object") {
						ScoreManager.AddScore (500);
						ScoreManager.IncreaseModifier ();
					} else if (go.tag == "Unhittable Object") {
						ScoreManager.ResetModifier ();
					}
				}
			}
		}
	}*/

		/*void OnTriggerEnter (Collider coll) {
			if (gameObject.tag == "Left Crusher") {
				coll.GetComponent<ObjectUtilities> ().inCrusher = ObjectUtilities.crusherState.left;
			} else if (gameObject.tag == "Right Crusher") {
				coll.GetComponent<ObjectUtilities> ().inCrusher = ObjectUtilities.crusherState.right;
			}
		}

		void OnTriggerExit (Collider coll) {
			coll.GetComponent<ObjectUtilities> ().inCrusher = ObjectUtilities.crusherState.none;
		}*/
	}
}