﻿using UnityEngine;
using System.Collections;

public class ObjectCatcher : MonoBehaviour {

	void OnTriggerEnter (Collider coll) {	//When a hittable object enters the detection zone, remove a life and reset the modifier
		if (coll.gameObject.tag == "Hittable Object") {
			ScoreManager.ResetModifier ();
			ScoreManager.RemoveLife ();
		}
	}
}
