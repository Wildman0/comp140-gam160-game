﻿using UnityEngine;
using System.Collections;

public class ObjectUtilities : MonoBehaviour {
	public enum crusherState { none, left, right }
	public crusherState inCrusher = crusherState.none;
}
