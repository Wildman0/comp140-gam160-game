﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ObjectManager : MonoBehaviour {

	public static List<GameObject> spawnedObjects;

	void Start () {
		List<GameObject> spawnedObjects = new List<GameObject> ();

		//Clears list on start to prevent any previous data being carried over
		spawnedObjects.Clear();
	}
}
