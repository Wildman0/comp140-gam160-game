﻿using UnityEngine;
using System.Collections;

public class SpeedManager : MonoBehaviour {

	public static float speedMod = 1f;

	void Start () {
		speedMod = 1f;
	}

	void Update () {
		speedMod += (Time.deltaTime/25);

		if (Input.GetKeyDown (KeyCode.KeypadPlus)) {
			speedMod += 0.5f;
		}

		ObjectSpawner.chanceToSpawn += Time.deltaTime / 2;

		if (Input.GetKeyDown (KeyCode.KeypadEnter)) {
			ObjectSpawner.chanceToSpawn += 2.5f;
		}

		Debug.Log (ObjectSpawner.chanceToSpawn);
	}
}
