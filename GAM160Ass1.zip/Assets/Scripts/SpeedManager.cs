﻿using UnityEngine;
using System.Collections;

public class SpeedManager : MonoBehaviour {

	public static float speedMod = 1f;

	void Start () {
		//Resets the speed modifier
		speedMod = 1f;
	}

	void Update () {
		//Gradually increases the speed of objects over time 
		speedMod += (Time.deltaTime/25);

		if (Input.GetKeyDown (KeyCode.KeypadPlus)) {	//Dev control to increase speed quickly
			speedMod += 0.5f;
		}

		//Increases object spawn chance over time 
		ObjectSpawner.chanceToSpawn += Time.deltaTime / 2;

		if (Input.GetKeyDown (KeyCode.KeypadEnter)) {	//Dev control to increase spawn chance quickly
			ObjectSpawner.chanceToSpawn += 2.5f;
		}
	}
}
