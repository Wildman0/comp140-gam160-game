﻿using UnityEngine;
using System.Collections;

public class Object : MonoBehaviour {
	enum crusherState {none, left, right }
	crusherState inCrusher = crusherState.none;

	public static void ObjectCrush (GameObject obj) {
		Destroy (obj);
	}
}
