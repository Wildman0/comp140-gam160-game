﻿using UnityEngine;
using System.Collections;

public class ScoreManager : MonoBehaviour {

	public static int scoreMod;
	public static int score;

	void Start () {
		ResetScore ();
	}

	public static void ResetScore () {
		score = 0;
		scoreMod = 1;
	}

	public static void AddScore (int i) {
		score += i * scoreMod;
	}

	public static void IncreaseModifier () {
		scoreMod += 1;
	}

	public static void ResetModifier () {
		scoreMod = 1;
	}

	public static void RemoveLife () {

	}
}
