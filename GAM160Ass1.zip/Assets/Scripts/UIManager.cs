﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class UIManager : MonoBehaviour {

	public static Text modifierText;
	public static Text scoreText;
	public static Image lifeBar;
	public static Text lifeText;

	void Start(){	//Sets UI components
		modifierText = GameObject.FindGameObjectWithTag ("Multiplier").GetComponent<Text>();
		scoreText = GameObject.FindGameObjectWithTag ("Score").GetComponent<Text> ();
		lifeText = GameObject.FindGameObjectWithTag ("Life Count").GetComponent<Text> ();
	}

	public static void OnScoreChange(int i){	//When told the score has changed, change the score text
		scoreText.text = i.ToString ();
	}

	public static void OnModifierChange(int i){	//When told the modifier has changed, change the modifier text
		modifierText.text = i.ToString ();
	}

	public static void OnLifeCountChange (int i) {	//When told the life count has changed, change the life coutn text
		lifeText.text = ("Lives: " + i.ToString ());
	}

	public static void OnLifeBarChange (float f) {
		lifeBar.fillAmount = f;
	}
}