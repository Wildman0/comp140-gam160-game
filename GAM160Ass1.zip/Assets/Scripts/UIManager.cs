﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class UIManager : MonoBehaviour {

	public static Text modifierText;
	public static Text scoreText;

	void Start(){
		modifierText = GameObject.FindGameObjectWithTag ("Multiplier").GetComponent<Text>();
		scoreText = GameObject.FindGameObjectWithTag ("Score").GetComponent<Text> ();
	}

	public static void OnScoreChange(int i){
		scoreText.text = i.ToString ();
	}

	public static void OnModifierChange(int i){
		modifierText.text = i.ToString ();
	}
}
