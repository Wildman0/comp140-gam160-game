﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ObjectManager : MonoBehaviour {

	public static List<GameObject> spawnedObjects;

	void Start () {
		//Clears list on start to prevetn any previous data being carried over
		spawnedObjects.Clear();
	}
}
