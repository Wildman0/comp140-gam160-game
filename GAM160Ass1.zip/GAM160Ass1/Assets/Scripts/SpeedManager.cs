﻿using UnityEngine;
using System.Collections;

public class SpeedManager : MonoBehaviour {

	
}
