﻿using UnityEngine;
using System.Collections;

public class ObjectSpawner : MonoBehaviour {

	public int chanceToSpawn = 50;  //Vague chance to spawn, between 0 and 2,000
	public int objectTypeSplit = 70;	//The percentage of objects that will spawn as hittable
	public float timeModifier;  //Modifier based on how long the player's been going for
	public float spawnModifier; //Modifier that increased when an object hasn't spawned for a while
	public GameObject hittableObject;	//Object the player is supposed to hit
	public GameObject unhittableObject; //Object the player isn't supposed to hit

	public Transform leftSpawnPosition;
	public Transform rightSpawnPosition;    //Possible spawn positions

	GameObject spawnedObject;	//Used to temporarily hold GameObjects after spawning

	enum side { left, right };	//Enum to handle which side the object spawns on

	void Awake () {
		//Fetches prefabs from the resources folder
		hittableObject = Resources.Load ("Hittable Object") as GameObject;
		unhittableObject = Resources.Load ("Unhittable Object") as GameObject;
	}

	void Update () {	//Called every frame
		ChooseToSpawn ();
	}

	void ChooseToSpawn () {	//Chooses whether or not an object is spawned this frame. If yes, choose spawn side
		if (Random.Range (0, 2000) < chanceToSpawn) {
			ChooseSpawnSide();
		}
	}

	void ChooseSpawnSide () {	//50/50 randomizes which side the object should spawn on
		if (Random.Range (0, 2) == 0) {
			SpawnObject (side.left);
		} else {
			SpawnObject (side.right);
		}
	}

	void SpawnObject (side spawnSide) { //Spawns the object on the specified side
		switch (spawnSide) {
			case side.left:
				//Instantiates at leftSpawnPosition
				//Spawned as spawnedObject in order to add them to the ObjectManager list
				spawnedObject = Instantiate (spawnObject(), new Vector3 (leftSpawnPosition.position.x, 
														leftSpawnPosition.position.y, 
														leftSpawnPosition.position.z), Quaternion.identity) as GameObject;
				break;

			case side.right:
				//Instantiates at rightSpawnPosition
				spawnedObject = Instantiate (spawnObject(), new Vector3 (rightSpawnPosition.position.x, 
														rightSpawnPosition.position.y, 
														rightSpawnPosition.position.z), Quaternion.identity) as GameObject;
				break;
		}
		ObjectManager.spawnedObjects.Add (spawnedObject);
	}

	GameObject spawnObject() {	//Chooses whether to spawn a hittable or unhittable object
		if (Random.Range (0, 100) > objectTypeSplit) {
			return unhittableObject;
		} else {
			return hittableObject;
		}
	}
}
